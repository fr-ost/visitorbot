gonative-android
================

This is the native Android code used by https://gonative.io/

It allows the creation of apps from existing mobile-optimized websites.

How to use
------------
Import into Android Studio. Edit appConfig.json as appropriate.

Licensing information available at https://gonative.io/
